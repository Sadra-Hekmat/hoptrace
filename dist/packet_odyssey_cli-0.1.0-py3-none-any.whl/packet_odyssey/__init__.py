"""Packet Odyssey CLI."""

__version__ = "0.1.0"
